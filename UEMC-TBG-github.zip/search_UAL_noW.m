%% 加载数据
clear
warning off all
addpath(genpath('./'));
% load dataset
load Caltech101-all_fea.mat  % Caltech101-20.mat Caltech101-all_fea.mat BDGP_fea.mat
truth = Y';
nCluster = length(unique(truth));
n = length(truth);
v = length(X);
for i = 1:v
    X{i} = X{i}';
end
%% 选择参数
% Caltech101-20: lambda1 = 1; lambda2 = 0.2; lambda3 = 0.5;
% lambda1可以选择[1,1000], 尽量偏高, 如100;
% lambda2和lambda3选择[0,1], 尽可能lambda2大于lambda3, 如[1,0.5],[1,0.2],[1,0.1]的组合;
% 数据集参数选取: 
% BDGP_fea.mat: lambda1 = 100; lambda2 = 1; lambda3 = 0.1, d=m=nCluster*2, iter=12, 'MM1';
% Caltech101-all_fea.mat: lambda1 = 100; lambda2 = 1; lambda3 = 0.1, d=m=nCluster*1, iter=10, 'MM1';
lambda1_range = [1,10,100,1000];
nCluster_range = [1,2,3];
result = zeros(4,3,8);
tic
for i = 1:length(lambda1_range)
    for j = 1:length(nCluster_range)
        para.lambda1 = i;  % 低秩的权重
        para.lambda2 = 1;  % 图融合的权重
        para.lambda3 = 0.1;  % 谱聚类的权重
        para.d = nCluster*j;
        para.m = nCluster*j;
        para.k = nCluster;
        para.MaxIter = 10;
        para.omega = ones(1,v)/v;
        pre_method = 'MM1';  % 'BN' 'LN' 'MM1' 'MM2' 'unit' 'no'
        % 运行UAL
        [G,W,A,Z,J,S,Y,obj,iter] = UAL_noW(X,para,pre_method);
        % 运行kmeans
        Gn = G(1:n,:);
        Gn_normalized = Gn ./ repmat(sqrt(sum(Gn.^2, 2)),1,size(Gn,2));  % 将Pn的每一行标准化为单位向量
        [idx] = kmeans(Gn_normalized,nCluster,'Replicates',20,'Distance','cosine');
        idx = idx';
        % 计算指标
        result(i,j,:) = Clustering8Measure(truth, idx);
    end
end
timer = toc;
timer = timer/12;