clear
warning off all
addpath(genpath('./'));

% 加载数据集
load cifar10.mat
truth = truelabel{1};
nCluster = length(unique(truth));
n = length(truth);
v = length(data);
for i = 1:v
    X{i} = data{i};
end
clear data index MissingStatus truelabel

% 设置参数
para.lambda1 = 100;
para.lambda2 = 1;
para.lambda3 = 1;
para.d = nCluster * 1;
para.m = nCluster * 1;
para.k = nCluster;
para.MaxIter = 20;
para.omega = [1,1,1];
pre_method = "unit";

% 初始化结果存储
num_runs = 10;
acc_values = zeros(1, num_runs);
nmi_values = zeros(1, num_runs);
purity_values = zeros(1, num_runs);
fscore_values = zeros(1, num_runs);
time_values = zeros(1, num_runs);

for i = 1:num_runs
    % 运行UAL
    tic
    [G, W, A, Z, J, S, Y, obj, iter] = UAL_fast(X, para, pre_method);
    timer = toc;

    % 运行kmeans
    Gn = G(1:n, :);
    Gn_normalized = Gn ./ repmat(sqrt(sum(Gn.^2, 2)), 1, size(Gn, 2));
    [idx] = kmeans(Gn_normalized, nCluster, 'Replicates', 20, 'Distance', 'cosine');
    result = Clustering8Measure(truth, idx);

    % 存储每次运行的结果
    acc_values(i) = result(1);
    nmi_values(i) = result(2);
    purity_values(i) = result(5);  % 从 result(5) 获取 Purity
    fscore_values(i) = result(4);
    time_values(i) = timer;

    % 输出当前运行的结果和进度
    fprintf('第 %d 次运行完成: ACC = %6.4f, NMI = %6.4f, Purity = %6.4f, Fscore = %6.4f, Time = %.1f seconds\n', i, result(1), result(2), result(5), result(4), timer);
end

% 计算平均值和标准差
mean_acc = mean(acc_values);
std_acc = std(acc_values);

mean_nmi = mean(nmi_values);
std_nmi = std(nmi_values);

mean_purity = mean(purity_values);
std_purity = std(purity_values);

mean_fscore = mean(fscore_values);
std_fscore = std(fscore_values);

mean_time = mean(time_values);
std_time = std(time_values);

% 打印最终平均结果
fprintf('\n平均结果：\n');
fprintf('ACC: %6.4f (±%6.4f) \n', mean_acc, std_acc);
fprintf('NMI: %6.4f (±%6.4f) \n', mean_nmi, std_nmi);
fprintf('Purity: %6.4f (±%6.4f) \n', mean_purity, std_purity);
fprintf('Fscore: %6.4f (±%6.4f) \n', mean_fscore, std_fscore);

