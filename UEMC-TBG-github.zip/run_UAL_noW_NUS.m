%% 加载数据
clear
warning off all
addpath(genpath('./'));
% load dataset
load NUSWIDEOBJ.mat  % Caltech101-20.mat Caltech101-all_fea.mat BDGP_fea.mat
truth = Y;
nCluster = length(unique(truth));
n = length(truth);
v = length(X);
for i = 1:v
    X{i} = X{i}';
    % X{i} = full(X{i});
end
%% 测试UAL
% Caltech101-20: lambda1 = 1; lambda2 = 0.2; lambda3 = 0.5;
% lambda1可以选择[1,1000], 尽量偏高, 如100;
% lambda2和lambda3选择[0,1], 尽可能lambda2大于lambda3, 如[1,0.5],[1,0.2],[1,0.1]的组合;
% 数据集参数选取: 
% MSRC_v1.mat: lambda1 = 1000; lambda2 = 1; lambda3 = 0.1, d=m=nCluster*2, iter=8, 'BN', rho=1;
% ORL_mtv.mat: lambda1 = 1000; lambda2 = 1; lambda3 = 1, d=m=nCluster*1, iter=15, 'BN';
% BDGP_fea.mat: lambda1 = 100; lambda2 = 1; lambda3 = 1, d=m=nCluster*2, iter=12, 'MM1';
% Caltech101-all_fea.mat: lambda1 = 100; lambda2 = 1; lambda3 = 0.1, d=m=nCluster*1, iter=10, 'MM1';
% Reuters.mat: lambda1 = 100; lambda2 = 1; lambda3 = 1, d=m=nCluster*1, iter=10, 'unit';

para.lambda1 = 100;  % 低秩的权重
para.lambda2 = 1;  % 图融合的权重
para.lambda3 = 1;  % 谱聚类的权重
para.d = nCluster*3;
para.m = nCluster*3;
para.k = nCluster;
para.MaxIter = 20;
para.omega = [0.1,1,0.1,0.1,1];
% para
pre_method = "unit";  % 'BN' 'LN' 'MM1' 'MM2' 'unit' 'no'
% 运行UAL
tic
[G,W,A,Z,J,S,Y,obj,iter] = UAL_fast(X,para,pre_method);
timer = toc;
%% 运行kmeans
Gn = G(1:n,:);
Gn_normalized = Gn ./ repmat(sqrt(sum(Gn.^2, 2)),1,size(Gn,2));  % 将Pn的每一行标准化为单位向量
[idx] = kmeans(Gn_normalized,nCluster,'Replicates',20,'Distance','cosine');
result = Clustering8Measure(truth, idx);
fprintf('Anchors: %d \t ACC: %6.4f \t NMI: %6.4f \t AR: %6.4f \t Fscore: %6.4f \t Time: %.1f second \n',[para.m result(1) result(2) result(3) result(4) timer]);
msgbox({'结果跑完了！'})
%% 可视化
% subplot(1,3,1)
% image(S,'CDataMapping','scaled')  % 二分图可视化
% subplot(1,3,2)
% image(S*S','CDataMapping','scaled')  % 完整相似度图可视化
% subplot(1,3,3)
% plot(obj)
%% 调参
% para_range = [1,10,20,30,40,50,60,70,80,90,100];
% result_turn = zeros(length(para_range),8);
% for i = 1:length(para_range)
%     para.lambda1 = para_range(i);
%     G = UAL_noW(X,para,pre_method);
%     Gn = G(1:n,:);
%     Gn_normalized = Gn ./ repmat(sqrt(sum(Gn.^2, 2)),1,size(Gn,2));  % 将Pn的每一行标准化为单位向量
%     [idx] = kmeans(Gn_normalized,nCluster,'Replicates',20,'Distance','cosine');
%     idx = idx';
%     result_turn(i,:) = Clustering8Measure(truth, idx);
% end